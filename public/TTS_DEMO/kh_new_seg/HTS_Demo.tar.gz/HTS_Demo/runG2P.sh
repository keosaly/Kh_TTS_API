/home/dotaplus/Documents/kh-g2p/KH-G2P/bin/phonetisaurus-apply-single --model /home/dotaplus/Documents/kh-g2p/KH-G2P/bin/train/model.fst --word_list ./output.txt
mv ./output.txt.pho ./phos/
rm ./text_single.txt 
#mv /home01/SLC/intern/saly.keo/kh-tts/data/text-result/*.pho /home01/SLC/intern/saly.keo/kh-tts/data/phos/


