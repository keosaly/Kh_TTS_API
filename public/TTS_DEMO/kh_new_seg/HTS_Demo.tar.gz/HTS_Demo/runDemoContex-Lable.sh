PATH=/share02/SLC/local/CENT6/SPTK-3.9/bin/:/home01/SLC/intern/saly.keo/local/CRF++/bin/:/share02/SLC/local/CENT6/python-2.7.10/bin/:/home01/SLC/intern/saly.keo/kh-g2p/KH-G2P/bin:/share02/SLC/local/CENT6/gcc-6.1.0/bin:/share02/SLC/local/CENT6/mitlm-0.4.2/bin:/share02/SLC/local/CENT6/openfst-1.6.5/bin:/usr/bin:/bin:/usr/sbin:/sbin

LD_LIBRARY_PATH=/share02/SLC/local/CENT6/ActiveTcl8.4.19.6/lib:/home01/SLC/intern/saly.keo/local/CRF++/lib/:/share02/SLC/local/CENT6/python-2.7.10/lib/:/share02/SLC/local/CENT6/mitlm-0.4.2/lib:/share02/SLC/local/CENT6/openfst-1.6.5/lib:/share02/SLC/local/CENT6/gcc-6.1.0/lib64

python sample.py

